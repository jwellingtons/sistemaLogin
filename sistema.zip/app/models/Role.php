<?php

/**
*
*/
class Role extends \HXPHP\System\Model
{

}