<?php
class IndexController extends \HXPHP\System\Controller
{
    public function indexAction()
    {
        $this->view->setPath('havefun');
    }
}